package com.example.spring.springsecurithbasic.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/users")
    public String getHello(){
        return "hello somesh";
    }

    @GetMapping("/bye")
    public String getBye(){
        return "hello tushar";
    }
}
